﻿using Anomaly_Detector.Models;
using Anomaly_Detector.Services;
using Emgu.CV;
using Emgu.CV.Structure;
using System;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media.Imaging;

namespace Anomaly_Detector.ViewModels
{
    public class SettingsViewModel : BaseViewModel
    {
        public ApplicationSettings ApplicationSettings { get; set; }

        // Commands for managing cameras, PLC endpoints, and preprocessing steps.
        public ICommand AddCameraCommand { get; set; }
        public ICommand RegisterPLCEndpointsCommand { get; set; }
        public ICommand AddPreprocessingStepCommand { get; set; }
        public ICommand RemovePreprocessingStepCommand { get; set; }
        public ICommand SortPreprocessingStepsCommand { get; set; }

        // Commands for connectivity and image capture.
        public ICommand CheckCameraConnectionCommand { get; set; }
        public ICommand CheckPLCConnectionCommand { get; set; }
        public ICommand CaptureStandardImageCommand { get; set; }
        public ICommand SaveSettingsCommand { get; set; }

        // Property to indicate connectivity.
        private bool _cameraConnected;
        public bool CameraConnected
        {
            get => _cameraConnected;
            set { _cameraConnected = value; OnPropertyChanged(); }
        }

        private bool _plcConnected;
        public bool PLCConnected
        {
            get => _plcConnected;
            set { _plcConnected = value; OnPropertyChanged(); }
        }

        // Property to hold the captured image for display.
        private BitmapSource _capturedImage;
        public BitmapSource CapturedImage
        {
            get => _capturedImage;
            set { _capturedImage = value; OnPropertyChanged(); }
        }

        // Property to control visibility of the Capture Standard Image button.
        private bool _showCaptureButton;
        public bool ShowCaptureButton
        {
            get => _showCaptureButton;
            set { _showCaptureButton = value; OnPropertyChanged(); }
        }

        // Initializes a new instance of the SettingsViewModel class.
        public SettingsViewModel()
        {
            ApplicationSettings = LoadSettings();  // Load saved settings

            // Other initialization code...
            ApplicationSettings.Cameras.CollectionChanged += Cameras_CollectionChanged;

            // Initialize commands
            AddCameraCommand = new RelayCommand(AddCamera);
            RegisterPLCEndpointsCommand = new RelayCommand(RegisterPLCEndpoints);
            AddPreprocessingStepCommand = new RelayCommand(AddPreprocessingStep);
            RemovePreprocessingStepCommand = new RelayCommand(RemovePreprocessingStep);
            SortPreprocessingStepsCommand = new RelayCommand(SortPreprocessingSteps);
            CheckCameraConnectionCommand = new RelayCommand(CheckCameraConnection);
            CheckPLCConnectionCommand = new RelayCommand(CheckPLCConnection);
            CaptureStandardImageCommand = new RelayCommand(CaptureStandardImage);
            SaveSettingsCommand = new RelayCommand(SaveSettings);
        }

        private ApplicationSettings LoadSettings()
        {
            var jsonService = new JsonDatabaseService<ApplicationSettings>("settings.json");
            return jsonService.LoadData() ?? new ApplicationSettings();  // Return default if no saved settings found
        }

        // Handles changes in the camera collection.
        private void Cameras_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            if (e.NewItems != null)
            {
                foreach (CameraModel cam in e.NewItems)
                {
                    if (cam is INotifyPropertyChanged notifier)
                    {
                        notifier.PropertyChanged += (s, ev) =>
                        {
                            if (ApplicationSettings.Cameras.Count > 0 && ApplicationSettings.Cameras[0] == cam)
                                CheckCameraConnection(null);
                        };
                    }
                }
            }
        }

        // Adds a new camera to the list.
        private void AddCamera(object parameter)
        {
            var newCamera = new CameraModel
            {
                CameraIndex = ApplicationSettings.Cameras.Count,
                Description = "New Camera"
            };
            ApplicationSettings.Cameras.Add(newCamera);
            if (ApplicationSettings.Cameras.Count == 1)
                CheckCameraConnection(null);
        }

        // Registers new PLC endpoints.
        private void RegisterPLCEndpoints(object parameter)
        {
            ApplicationSettings.PLCEndpoints.Add(new PLCEndpoint
            {
                Name = "Endpoint " + (ApplicationSettings.PLCEndpoints.Count + 1),
                RegisterAddress = 100
            });
        }

        // Adds a preprocessing step.
        private void AddPreprocessingStep(object parameter)
        {
            int order = ApplicationSettings.PreprocessingSteps.Count + 1;
            ApplicationSettings.PreprocessingSteps.Add(new PreprocessingStep
            {
                Order = order,
                StepName = "New Step",
                Parameters = ""
            });
        }

        // Removes the last preprocessing step.
        private void RemovePreprocessingStep(object parameter)
        {
            if (ApplicationSettings.PreprocessingSteps.Count > 0)
            {
                ApplicationSettings.PreprocessingSteps.RemoveAt(ApplicationSettings.PreprocessingSteps.Count - 1);
            }
        }

        // Sorts preprocessing steps by their order.
        private void SortPreprocessingSteps(object parameter)
        {
            var sorted = new System.Collections.Generic.List<PreprocessingStep>(ApplicationSettings.PreprocessingSteps);
            sorted.Sort((x, y) => x.Order.CompareTo(y.Order));
            ApplicationSettings.PreprocessingSteps.Clear();
            foreach (var step in sorted)
            {
                ApplicationSettings.PreprocessingSteps.Add(step);
            }
        }

        // Checks the connectivity of the first configured camera.
        private void CheckCameraConnection(object parameter)
        {
            foreach (var camera in ApplicationSettings.Cameras)
            {
                try
                {
                    using (var cameraService = new CameraService(camera.CameraIndex))
                    {
                        var frame = cameraService.GetCurrentFrame();
                        if (frame != null)
                        {
                            camera.IsConnected = true;
                            camera.ConnectionColor = "Green";  // Green if connected
                        }
                        else
                        {
                            camera.IsConnected = false;
                            camera.ConnectionColor = "Gray";  // Gray if disconnected
                        }
                    }
                }
                catch (Exception ex)
                {
                    camera.IsConnected = false;
                    camera.ConnectionColor = "Gray";  // Set to gray on error
                    Console.WriteLine($"Error connecting to camera {camera.CameraIndex}: {ex.Message}");
                }
            }
        }


        // Checks the connectivity of the PLC by attempting to read a register.
        private void CheckPLCConnection(object parameter)
        {
            try
            {
                using (var modbusService = new ModbusService(ApplicationSettings.PLCConfiguration))
                {
                    var registers = modbusService.ReadHoldingRegisters(0, 1);
                    PLCConnected = (registers != null);
                }
            }
            catch (Exception ex)
            {
                PLCConnected = false;
                Console.WriteLine($"PLC connection error: {ex.Message}");
            }
        }

        // Captures a standard image from the first connected camera.
        private void CaptureStandardImage(object parameter)
        {
            var selectedCamera = ApplicationSettings.Cameras.FirstOrDefault(cam => cam.IsConnected);
            if (selectedCamera != null)
            {
                try
                {
                    using (var cameraService = new CameraService(selectedCamera.CameraIndex))
                    {
                        var frame = cameraService.GetCurrentFrame();
                        if (frame != null)
                        {
                            string storagePath = ApplicationSettings.ImageStoragePath ??
                                System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "AnomalyDetectorImages");

                            if (!System.IO.Directory.Exists(storagePath))
                            {
                                System.IO.Directory.CreateDirectory(storagePath);
                            }

                            string fileName = $"camera_{selectedCamera.CameraIndex}_standard.jpg";
                            string filePath = System.IO.Path.Combine(storagePath, fileName);
                            frame.Save(filePath);

                            // Update path in camera settings
                            selectedCamera.StandardImagePath = filePath;

                            // Convert frame to BitmapSource for display
                            CapturedImage = frame.ToBitmapSource();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error capturing standard image: {ex.Message}");
                }
            }
        }

        // Saves the current application settings to a JSON file.
        private void SaveSettings(object parameter)
        {
            try
            {
                var jsonService = new JsonDatabaseService<ApplicationSettings>("settings.json");
                jsonService.SaveData(ApplicationSettings);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving settings: {ex.Message}");
            }
        }
    }
}
